﻿namespace Karta
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button_reload = new Button();
            button_generatePDF = new Button();
            pictureBox1 = new PictureBox();
            button_edit = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button_reload
            // 
            button_reload.Location = new Point(165, 327);
            button_reload.Name = "button_reload";
            button_reload.Size = new Size(131, 53);
            button_reload.TabIndex = 2;
            button_reload.Text = "Reload";
            button_reload.UseVisualStyleBackColor = true;
            button_reload.Click += button1_Click;
            // 
            // button_generatePDF
            // 
            button_generatePDF.Location = new Point(354, 327);
            button_generatePDF.Name = "button_generatePDF";
            button_generatePDF.Size = new Size(112, 53);
            button_generatePDF.TabIndex = 3;
            button_generatePDF.Text = "PDF";
            button_generatePDF.UseVisualStyleBackColor = true;
            button_generatePDF.Click += button_generatePDF_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Gainsboro;
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Enabled = false;
            pictureBox1.Location = new Point(310, 115);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(240, 160);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            pictureBox1.Visible = false;
            pictureBox1.Click += pictureBox1_Click;
            pictureBox1.Paint += pictureBox1_Paint;
            pictureBox1.MouseClick += pictureBox1_MouseClick;
            // 
            // button_edit
            // 
            button_edit.Location = new Point(545, 327);
            button_edit.Name = "button_edit";
            button_edit.Size = new Size(125, 53);
            button_edit.TabIndex = 5;
            button_edit.Text = "Edit";
            button_edit.UseVisualStyleBackColor = true;
            button_edit.Click += button_edit_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(898, 460);
            Controls.Add(button_edit);
            Controls.Add(pictureBox1);
            Controls.Add(button_generatePDF);
            Controls.Add(button_reload);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Button button_reload;
        private Button button_generatePDF;
        private PictureBox pictureBox1;
        private Button button_edit;
    }
}