﻿namespace Karta
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button_reload = new Button();
            button_generatePDF = new Button();
            SuspendLayout();
            // 
            // button_reload
            // 
            button_reload.Location = new Point(60, 117);
            button_reload.Name = "button_reload";
            button_reload.Size = new Size(131, 53);
            button_reload.TabIndex = 2;
            button_reload.Text = "Reload";
            button_reload.UseVisualStyleBackColor = true;
            button_reload.Click += button1_Click;
            // 
            // button_generatePDF
            // 
            button_generatePDF.Location = new Point(280, 117);
            button_generatePDF.Name = "button_generatePDF";
            button_generatePDF.Size = new Size(112, 53);
            button_generatePDF.TabIndex = 3;
            button_generatePDF.Text = "PDF";
            button_generatePDF.UseVisualStyleBackColor = true;
            button_generatePDF.Click += button_generatePDF_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(469, 271);
            Controls.Add(button_generatePDF);
            Controls.Add(button_reload);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion
        private Button button_reload;
        private Button button_generatePDF;
    }
}