using PdfSharp.Drawing;
using System.Drawing;

namespace Karta
{
    public partial class Form1 : Form
    {
        Contoller contoller = new Contoller();
        List<Rectangle> rectangles = new List<Rectangle>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            XUnit xWidth = XUnit.FromMillimeter(85.6);
            XUnit xHeight = XUnit.FromMillimeter(53.98);
            int pointWidth = Convert.ToInt32(Math.Round(xWidth.Point * 4.16666));
            int pointHeight = Convert.ToInt32(Math.Round(xHeight.Point * 4.16666));
            Width = pointWidth; //500;
            Height = pointHeight; //350;

            contoller.LoadCardsFromFiles();

            pictureBox1.Paint += pictureBox1_Paint;
            pictureBox1.MouseClick += pictureBox1_MouseClick;
            //this.pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            contoller.LoadCardsFromFiles();
            MessageBox.Show("data byla na�tena");
        }

        private void button_generatePDF_Click(object sender, EventArgs e)
        {
            contoller.MakePDF();
        }
        private void button_edit_Click_1(object sender, EventArgs e)
        {
            pictureBox1.Enabled = true;
            pictureBox1.Visible = true;
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new Pen(Color.Black);
            foreach (Rectangle rectangle in rectangles)
            {
                e.Graphics.DrawRectangle(pen, rectangle);
            }
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            int x = (int)e.X;
            int y = (int)e.Y;

            contoller.PridatPoziciTextu(x, y);
            Rectangle rectangle = new Rectangle(x, y, 40, 10);
            rectangles.Add(rectangle);
            pictureBox1.Invalidate();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}