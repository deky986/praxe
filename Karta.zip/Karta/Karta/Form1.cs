namespace Karta
{
    public partial class Form1 : Form
    {
        Card card = new Card();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Width = 500;
            Height = 350;

            card.AddText();
            card.AddPictures();
            this.pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(card.ToString());
            this.pictureBox1.Image = card.images[5];
        }
    }
}