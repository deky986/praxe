using PdfSharp.Drawing;

namespace Karta
{
    public partial class Form1 : Form
    {
        Manager manager = new Manager();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Width = 500;
            Height = 350;

            manager.AddText();
            manager.AddPictures();
            this.pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            manager.texts.Clear();
            manager.AddText();
            MessageBox.Show("data byla na�tena");
            manager.GeneratePDF();
        }
    }
}