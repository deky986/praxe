﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Karta
{
    internal class Pozice
    {
        public double x;
        public double y;

        public Pozice(double x, double y)
        {
            this.x = x;
            this.y = y;
        }
    }
}
