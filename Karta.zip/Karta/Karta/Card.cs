﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using static System.Net.Mime.MediaTypeNames;
using System.Text.Unicode;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System.Drawing.Imaging;

namespace Karta
{
    public class Card
    {
        public System.Drawing.Image image { get; set; }

        public List<string> texts = new List<string>();
        public List<Bitmap> images = new List<Bitmap>();


    }
}
