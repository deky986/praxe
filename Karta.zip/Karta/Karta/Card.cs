﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using static System.Net.Mime.MediaTypeNames;
using System.Text.Unicode;

namespace Karta
{
    public class Card
    {
        public System.Drawing.Image image { get; set; }

        public List<string> texts = new List<string>();
        public List<Bitmap> images = new List<Bitmap>();
        public Dictionary<int, string[]> cards = new Dictionary<int, string[]>();

        public void AddText()
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            string textPath = @"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\txt\";
            int getCount = Directory.GetFiles(textPath).Length;

            for (int i = 0; i < getCount; i++)
            {
                string next = $@"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\txt\ID_Person_{i}.txt";
                string[] done = File.ReadAllLines(next, Encoding.GetEncoding(1250));
                texts.AddRange(done);
            }
        }

        public void AddPictures()
        {
            string picturePath = @"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\obr";
            int getCount= Directory.GetFiles(picturePath).Length;

            for (int i = 0; i < getCount; i++)
            {
                images.Add(new Bitmap($@"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\obr\ID_Person_{i}.jpg"));
            }
        }

        public override string ToString()
        {
            return string.Join(Environment.NewLine, texts); 
        }
    }
}
