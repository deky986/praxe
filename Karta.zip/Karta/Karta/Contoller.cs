﻿using Microsoft.VisualBasic.ApplicationServices;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Karta
{
    internal class Contoller
    {
        #region sizeData
        private XFont font = new XFont("Arial", 10);
        private XBrush colour = XBrushes.Black;
        private int pocetTextuNaKarte = 3;

        private int imgWidth = 80;
        private int imgHeight = 95;

        private int margin = 20; //vzdálenost karty od kraje papíru
        private int space = 10; //mezera mezi jednotlivými kartami
        private int cardsPerRow = 2;

        public List<Pozice> poziceTxt = new List<Pozice>()
        {
            new Pozice(100, 30),
            new Pozice(100, 80),
            new Pozice(100, 130)
        };

        public List<Pozice> poziceImg = new List<Pozice>()
        {
            new Pozice(10, 10),        
        };
        #endregion
       
        public List<Karta> cards;

        public void LoadCardsFromFiles()
        {
            cards = new List<Karta>();

            //karta.images.Add(fcs);
            //karta.texts.Add()

            for (int i = 0; i < 10; i++)
            {
                Karta karta = new Karta();
                string textPath = $@"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\txt\ID_Person_{i}.txt";
                string imgPath = $@"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\obr\ID_Person_{i}.jpg";
                LoadCardFromFile(karta, textPath, imgPath);
                cards.Add(karta);
            }
        }

        public void LoadCardFromFile(Karta card, string textPath, string imgPath)
        {
            string[] lines = File.ReadAllLines(textPath, Encoding.UTF8);
            card.texts.AddRange(lines.Take(pocetTextuNaKarte));

            // Načíst obrázek
            Bitmap img = new Bitmap(imgPath);
            card.images.Add(img);
        }

        public void MakePDF()
        {
            var pdf = new PdfDocument();
            int cardWidth = 240;
            int cardHeight = 160;

            int cardX = margin;
            int cardY = margin;


            PdfPage page = pdf.AddPage();
            page.Width = XUnit.FromMillimeter(210);
            page.Height = XUnit.FromMillimeter(297);
            XGraphics gfx = XGraphics.FromPdfPage(page);
            XImage background = XImage.FromFile(@"C:\Users\Klepacev\Desktop\Karta\Karta\pozadi1.jpg");

            foreach (var karta in cards)
            {
                gfx.DrawRectangle(XPens.Black, cardX, cardY, cardWidth, cardHeight);
                gfx.DrawImage(background, cardX, cardY, cardWidth, cardHeight);

                int j = 0;
                foreach (var image in karta.images)             
                {
                    using (var ms = new MemoryStream())
                    {
                        image.Save(ms, ImageFormat.Png);
                        ms.Position = 0;
                        var img = XImage.FromStream(ms);
                        gfx.DrawImage(img, cardX + poziceImg[j].x, cardY + poziceImg[j].y, imgWidth, imgHeight);
                        j++;
                    }
                }
                // Vykreslí texty na pozice relativně k pozici karty
                for (int i = 0; i < Math.Min(karta.texts.Count, poziceTxt.Count); i++)
                {
                    gfx.DrawString(karta.texts[i], font, colour, cardX + poziceTxt[i].x, cardY + poziceTxt[i].y);
                }

                if ((cards.IndexOf(karta) + 1) % cardsPerRow == 0)
                {
                    cardX = margin;
                    cardY += cardHeight + space;
                }
                else
                {
                    cardX += cardWidth + space;
                }

                if (cardY + cardHeight > page.Height.Point)
                {
                    page = pdf.AddPage();
                    page.Width = XUnit.FromMillimeter(210);
                    page.Height = XUnit.FromMillimeter(297);
                    gfx = XGraphics.FromPdfPage(page);
                    cardX = margin;
                    cardY = margin;
                }
            }

            string path = @"C:\Users\Klepacev\Desktop\cards_output.pdf";
            pdf.Save(path);
            MessageBox.Show("PDF bylo vytvořeno.");
        }
    }
}
