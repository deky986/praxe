﻿using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static PdfSharp.Capabilities.Features;

namespace Karta
{
    public class Manager : Card
    {
        public void GeneratePDF()
        {
            PdfDocument pdf = new PdfDocument();
            PdfPage page = new PdfPage();
            page.Width = XUnit.FromMillimeter(210);
            page.Height = XUnit.FromMillimeter(297);
        }

        public void AddText()
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            string textPath = @"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\txt\";
            int getCount = Directory.GetFiles(textPath).Length;

            for (int i = 0; i < getCount; i++)
            {
                string next = $@"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\txt\ID_Person_{i}.txt";
                string[] done = File.ReadAllLines(next, Encoding.GetEncoding(1250));
                texts.AddRange(done);
            }
        }

        public void AddPictures()
        {
            string picturePath = @"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\obr";
            int getCount = Directory.GetFiles(picturePath).Length;

            for (int i = 0; i < getCount; i++)
            {
                images.Add(new Bitmap($@"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\obr\ID_Person_{i}.jpg"));
            }
        }

        public override string ToString()
        {
            return string.Join(Environment.NewLine, texts);
        }
    }
}
