﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hra_dvourozměrné_pole
{
    public class Pole
    {
        public int width;
        public int height;

        /*for (l = 0; l < n; l++)
            {
                for (int i = 0; i < m; i++)
                {
                    int value = a.Next(0, 2);
                    if (value == 1)
                    {
                        tabulka[i, l] = true;
                    }
                    else
                    {
                        tabulka[i, l] = false;
                    }
                }
                for (int j = 0; j < 7; j++)
                {
                    if (tabulka[j, 0])
                    {
                        Console.Write("X");
                    }
                    else// if (tabulka[j, l] == false)
                    {
                        Console.Write("O");
                    }
                }
                Console.WriteLine();
            }
            */
    }
}
