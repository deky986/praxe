﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Hra_dvourozměrné_pole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("How many columns do you want the board to have?");
            int m = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("How many rows do you want the table to have?");
            int n = Convert.ToInt32(Console.ReadLine());
            bool[,] tabulka = FillBoard(m, n);
            DrawBoard(tabulka);
            Console.ReadKey();
            Console.Clear();
            while (true)
            {
                DrawBoard(tabulka);
                ChangeBoard(tabulka, m, n);
                DrawBoard(tabulka);
                Console.ReadKey();
                Console.Clear();
            }
        }

        public static bool[,] FillBoard(int m, int n)
        {
            bool[,] tabulka = new bool[m, n];
            Random a = new Random();
            for (int l = 0; l < n; l++)
            {
                for (int i = 0; i < m; i++)
                {
                    int value = a.Next(0, 2);
                    tabulka[i, l] = value == 1;
                }
            }
            return tabulka;
        }

        public static void DrawBoard(bool[,] tabulka, int n)
        {
            n = n - 1;
            while (n >= 0)
            {
                for (int j = 0; j < tabulka.GetLength(0); j++)
                {
                    if (tabulka[j, n])
                    {
                        Console.Write("X");
                    }
                    else// if (tabulka[j, l] == false)
                    {
                        Console.Write("O");
                    }
                }
                n--;
                Console.WriteLine();
            }
        }

        public static void DrawBoard(bool[,] tabulka)
        {
            for (int i = 0; i < tabulka.GetLength(1); i++)
            {
                for (int j = 0; j < tabulka.GetLength(0); j++)
                {
                    Console.Write(tabulka[j, i] ? "X" : "O");
                }
                Console.WriteLine();
            }
        }

        public static void ChangeBoard(bool[,] tabulka, int m, int n)
        {
            try
            {
                Console.WriteLine("At what coordinates do you want to make the change?");
                Console.Write("x: ");
                int x = Convert.ToInt32(Console.ReadLine());
                Console.Write("y: ");
                int y = Convert.ToInt32(Console.ReadLine());

                tabulka[x, y] = !tabulka[x, y];

                if (x >= 1 && tabulka[x-1,y])
                {
                    tabulka[x-1, y] = !tabulka[x - 1, y];
                }
                else if (x >= 1 && tabulka[x - 1, y] == false)
                {
                    tabulka[x-1, y] = !tabulka[x - 1, y];
                }

                if (x < m-1 && tabulka[x + 1, y])
                {
                    tabulka[x+1, y] = !tabulka[x + 1, y];
                }
                else if (x < m-1 && tabulka[x + 1, y] == false)
                {
                    tabulka[x+1, y] = !tabulka[x + 1, y];
                }

                if (y >= 1 && tabulka[x, y - 1])
                {
                    tabulka[x, y - 1] = !tabulka[x, y - 1];
                }
                else if (y >= 1 && tabulka[x, y - 1] == false)
                {
                    tabulka[x, y - 1] = !tabulka[x, y - 1];
                }

                if (y < n - 1 && tabulka[x, y + 1])
                {
                    tabulka[x, y + 1] = !tabulka[x, y + 1];
                }
                else if (y < n - 1 && tabulka[x, y + 1] == false)
                {
                    tabulka[x, y + 1] = !tabulka[x, y + 1];
                }
        }
        catch
        {
            Console.WriteLine("No.");
        }



        }
        //public static void FilllRandomBoard(ref bool[,] tab)
        //{

        //}
    }
}
