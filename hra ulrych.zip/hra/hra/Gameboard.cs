﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hra
{
    public class Gameboard
    {
        private int Width { get; set; }
        private int Height { get; set; }
        public bool[,] Board { get; set; }
        private int X { get; set; } = 1;
        private int Y { get; set; } = 1;
        public Gameboard(int height, int width)
        {
            this.Width = width;
            this.Height = height;
            Board = new bool[height, width];
        }

        public void Draw()
        {
            Console.Clear();

            int realWidth = (Width * 2) + 1;
            int realHeight = (Height * 2) + 1;

            for (int i = 0; i < Board.GetLength(0); i++)
            {
                for (int j = 0; j < realWidth; j++)
                {
                    Console.Write("-");
                }
                Console.WriteLine();

                for (int r = 0; r < Board.GetLength(1); r++)
                {
                    Console.Write("|" + (Board[i, r] ? "X" : "O"));

                    if (r == Board.GetLength(1) - 1)
                    {
                        Console.Write("|");
                    }
                }
                Console.WriteLine();
            }

            for (int i = 0; i < realWidth; i++)
            {
                Console.Write("-");
            }

            Console.SetCursorPosition(X, Y);

            if (CheckWin()) 
            {
                Console.SetCursorPosition(realWidth, realHeight);
                Console.WriteLine();
                Console.WriteLine("KONEC HRY");
                Environment.Exit(0);
            }
        }
        public void CreateBoard()
        {
            Random rnd = new Random();

            for (int i = 0; i < Board.GetLength(0); i++)
            {
                for (int r = 0; r < Board.GetLength(1); r++)
                {
                    Board[i, r] = rnd.Next(2) == 0;
                }
            }
        }

        public void Movement(ConsoleKeyInfo info)
        {
            int newX = X;
            int newY = Y;

            int realWidth = (Width * 2) + 1;
            int realHeight = (Height * 2) + 1;

            if (info.Key == ConsoleKey.UpArrow)
            {
                newY -= 2;
            }
            else if (info.Key == ConsoleKey.DownArrow)
            {
                newY += 2;
            }
            else if (info.Key == ConsoleKey.LeftArrow)
            {
                newX -= 2;
            }
            else if (info.Key == ConsoleKey.RightArrow)
            {
                newX += 2;
            }
            else if (info.Key == ConsoleKey.Spacebar)
            {
                SymbolsChange(X / 2, Y / 2);
            }
            else if(info.Key == ConsoleKey.Escape) 
            {
                Environment.Exit(0);
            }

            if (newX >= 0 && newX < realWidth && newY >= 0 && newY < realHeight)
            {
                X = newX;
                Y = newY;
            }
            else
            {
                newX = X;
                newY = Y;
            }
        }
        private void SymbolsChange(int x, int y)
        {
            if (y - 1 >= 0 && y < Board.GetLength(0))
            {
                Board[y - 1, x] = !Board[y - 1, x];
            }
            if (y >= 0 && y + 1 < Board.GetLength(0))
            {
                Board[y + 1, x] = !Board[y + 1, x];
            }
            if (x - 1 >= 0 && x < Board.GetLength(1))
            {
                Board[y, x - 1] = !Board[y, x - 1];
            }
            if (x >= 0 && x + 1 < Board.GetLength(1))
            {
                Board[y, x + 1] = !Board[y, x + 1];
            }

        }

        private bool CheckWin() 
        {
            bool allTrue = true;
            bool allFalse = true;

            foreach (bool value in Board) 
            {
                if (value == false) 
                {
                    allTrue = false;
                    break;
                }
            }

            foreach (bool value in Board)
            {
                if (value == true) 
                {
                    allFalse = false;
                    break;
                }
            }

            return allTrue || allFalse;
        }
    }
}
