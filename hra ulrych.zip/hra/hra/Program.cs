﻿namespace hra
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Zadej šířku hracího pole");
            int width = Convert.ToInt32(Console.ReadLine());
            Console.Clear();

            Console.WriteLine("Zadej výšku hracího pole");
            int height = Convert.ToInt32(Console.ReadLine());

            Gameboard gameboard = new Gameboard(height,width);

            gameboard.CreateBoard();
            gameboard.Draw();

            Console.SetCursorPosition(1,1);

            while (true) 
            {
                ConsoleKeyInfo key = Console.ReadKey();
                gameboard.Movement(key);
                gameboard.Draw();
            }
            
        }
    }
}
