﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Karta
{
    public partial class PointEdit : UserControl
    {
        private Pozice bod;
        public Pozice Bod
        {
            get
            {
                //bod.x = Convert.ToDouble(textBox1.Text);
                //bod.y = Convert.ToDouble(textBox2.Text);
                return bod;
            }
            set
            {
                settingPositionByCode = true;
                bod = value;
                textBox1.Text = bod.x.ToString();
                textBox2.Text = bod.y.ToString();
                settingPositionByCode = false;
            }
        }

        private bool settingPositionByCode;

        public EventHandler ValueChanged { get; set; }

        public PointEdit()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!settingPositionByCode)
            {
                if (double.TryParse(textBox1.Text, out double bodX))
                {
                    bod.x = bodX;
                }
                if (double.TryParse(textBox2.Text, out double bodY))
                {
                    bod.y = bodY;
                }
                ValueChanged?.Invoke(this, EventArgs.Empty);
            }
        }
    }
}
