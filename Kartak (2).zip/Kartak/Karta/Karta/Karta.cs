﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Karta
{
    internal class Karta
    {
        public List<string> texts = new List<string>();
        public List<Bitmap> images = new List<Bitmap>();
    }
}
