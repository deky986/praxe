﻿using Microsoft.VisualBasic.ApplicationServices;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using static PdfSharp.Capabilities.Features;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrayNotify;

namespace Karta
{
    public class Manager : Card
    {
        public void GeneratePDF()
        {
            PdfDocument pdf = new PdfDocument();
            PdfPage page = pdf.AddPage();

            XGraphics gfx = XGraphics.FromPdfPage(page);

            const int cardsPerRow = 2;
            //const int cardWidth = 240;
            //const int cardHeight = 160;
            double cardWidth = XUnit.FromMillimeter(85.6).Point;
            double cardHeight = XUnit.FromMillimeter(53.98).Point;
            const int margin = 20;
            const int spacing = 10;

            double x = margin;
            double y = margin;

            XImage background = XImage.FromFile(@"C:\Users\olomouc\Desktop\Karta\background.png");

            for (int i = 0; i < images.Count; i++)
            {
                gfx.DrawImage(background, x, y, cardWidth, cardHeight);
                gfx.DrawRectangle(XPens.Black, x, y, cardWidth, cardHeight);
                    
                using (MemoryStream ms = new MemoryStream())
                {
                    images[i].Save(ms, ImageFormat.Png);
                    XImage img = XImage.FromStream(ms);
                    gfx.DrawImage(img, x + 10, y + 10, 80, 100);

                    var font = new XFont("Arial", 10, XFontStyleEx.Bold);
                    gfx.DrawString(texts[i * 3], font, XBrushes.Black, new XPoint(x + 100, y + 30));
                    gfx.DrawString(texts[i * 3 + 1], font, XBrushes.Black, new XPoint(x + 100, y + 50));
                    gfx.DrawString(texts[i * 3 + 2], font, XBrushes.Black, new XPoint(x + 100, y + 70));

                    if ((i + 1) % cardsPerRow == 0)
                    {
                        x = margin;
                        y += cardHeight + spacing;
                    }
                    else
                    {
                        x += cardWidth + spacing;
                    }

                    if (y + cardHeight > page.Height.Point)
                    {
                        page = pdf.AddPage();
                        page.Width = XUnit.FromMillimeter(210);
                        page.Height = XUnit.FromMillimeter(297);
                        gfx = XGraphics.FromPdfPage(page);
                        x = margin;
                        y = margin;
                    }
                }
            }

            pdf.Save(@"C:\Users\olomouc\Downloads\sssvtpdf\idk.pdf");
        }

        public void AddText()
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            string textPath = @"C:\Users\olomouc\Desktop\Karta\Karta\Karta\10_Lidí\txt";
            int getCount = Directory.GetFiles(textPath).Length;

            for (int i = 0; i < getCount; i++)
            {
                string next = $@"C:\Users\olomouc\Desktop\Karta\Karta\Karta\10_Lidí\txt\ID_Person_{i}.txt";
                string[] done = File.ReadAllLines(next, Encoding.GetEncoding(1250));
                texts.AddRange(done);
            }
        }

        public void AddPictures()
        {
            string picturePath = @"C:\Users\olomouc\Desktop\Karta\Karta\Karta\10_Lidí\obr";
            int getCount = Directory.GetFiles(picturePath).Length;

            for (int i = 0; i < getCount; i++)
            {
                images.Add(new Bitmap($@"C:\Users\olomouc\Desktop\Karta\Karta\Karta\10_Lidí\obr\ID_Person_{i}.jpg"));
            }
        }

        public override string ToString()
        {
            return string.Join(Environment.NewLine, texts);
        }
    }
}
