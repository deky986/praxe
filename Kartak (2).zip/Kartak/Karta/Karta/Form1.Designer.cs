﻿namespace Karta
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button_reload = new Button();
            button_generatePDF = new Button();
            pictureBox1 = new PictureBox();
            button_edit = new Button();
            button_delete = new Button();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button_reload
            // 
            button_reload.Location = new Point(109, 370);
            button_reload.Margin = new Padding(3, 4, 3, 4);
            button_reload.Name = "button_reload";
            button_reload.Size = new Size(90, 46);
            button_reload.TabIndex = 2;
            button_reload.Text = "Reload";
            button_reload.UseVisualStyleBackColor = true;
            button_reload.Click += button1_Click;
            // 
            // button_generatePDF
            // 
            button_generatePDF.Location = new Point(298, 370);
            button_generatePDF.Margin = new Padding(3, 4, 3, 4);
            button_generatePDF.Name = "button_generatePDF";
            button_generatePDF.Size = new Size(85, 46);
            button_generatePDF.TabIndex = 3;
            button_generatePDF.Text = "PDF";
            button_generatePDF.UseVisualStyleBackColor = true;
            button_generatePDF.Click += button_generatePDF_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Gainsboro;
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Enabled = false;
            pictureBox1.Location = new Point(109, 131);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(274, 213);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            pictureBox1.Visible = false;
            pictureBox1.VisibleChanged += pictureBox1_Load;
            pictureBox1.Paint += pictureBox1_Paint;
            pictureBox1.MouseClick += pictureBox1_MouseClick;
            // 
            // button_edit
            // 
            button_edit.Location = new Point(205, 370);
            button_edit.Margin = new Padding(3, 4, 3, 4);
            button_edit.Name = "button_edit";
            button_edit.Size = new Size(87, 46);
            button_edit.TabIndex = 5;
            button_edit.Text = "Edit";
            button_edit.UseVisualStyleBackColor = true;
            button_edit.Click += button_edit_Click_1;
            // 
            // button_delete
            // 
            button_delete.Enabled = false;
            button_delete.Location = new Point(565, 435);
            button_delete.Name = "button_delete";
            button_delete.Size = new Size(129, 56);
            button_delete.TabIndex = 6;
            button_delete.Text = "Delete";
            button_delete.UseVisualStyleBackColor = true;
            button_delete.Visible = false;
            button_delete.Click += button_delete_Click;
            // 
            // panel1
            // 
            panel1.Location = new Point(523, 52);
            panel1.Name = "panel1";
            panel1.Size = new Size(290, 366);
            panel1.TabIndex = 7;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1026, 613);
            Controls.Add(panel1);
            Controls.Add(button_delete);
            Controls.Add(button_edit);
            Controls.Add(pictureBox1);
            Controls.Add(button_generatePDF);
            Controls.Add(button_reload);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Margin = new Padding(3, 4, 3, 4);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Button button_reload;
        private Button button_generatePDF;
        private PictureBox pictureBox1;
        private Button button_edit;
        private Button button_delete;
        private Panel panel1;
    }
}