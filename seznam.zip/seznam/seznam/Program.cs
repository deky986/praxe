﻿namespace seznam
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person per = new Person();

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Co chcete udělat? (zmáčkněte číslo)");
                Console.WriteLine("1. Přidat uživatele");
                Console.WriteLine("2. Odebrat uživatele");
                Console.WriteLine("3. Upravit uživatele");
                Console.WriteLine("4. Zobrazit seznam uživatelů");
                Console.WriteLine("5. Zavřít program");
                try
                {
                    int response = Convert.ToInt16(Console.ReadLine());
                
                    switch (response)
                    {
                        case 1:
                            Console.Clear();

                            Person person = new Person();

                            //Křestní jméno
                            Console.WriteLine("Zadejte křestní jméno");
                            person.name = Console.ReadLine();
                            Console.Clear();

                            //Příjmení
                            Console.WriteLine("Zadejte příjmení");
                            person.surname = Console.ReadLine();
                            Console.Clear();

                            per.people.Add(person);

                            break;
                        case 2:
                            Console.Clear();

                            Console.WriteLine("Kterého uživatele chcete odstranit?");

                            per.PeopleList();

                            int index1 = Convert.ToInt32(Console.ReadLine());

                            per.people.RemoveAt(index1 - 1);
                            break;
                        case 3:
                            Console.Clear();
                            Console.WriteLine("Kterého uživatele chcete odstranit?");

                            per.PeopleList();

                            int index = Convert.ToInt32(Console.ReadLine());

                            //Křestní jméno
                            Console.Clear();
                            Console.WriteLine("Zadejte křestní jméno");
                            per.people.ElementAt(index - 1).name = Console.ReadLine();

                            //Příjmení
                            Console.Clear();
                            Console.WriteLine("Zadejte příjmení");
                            per.people.ElementAt(index - 1).surname = Console.ReadLine();
                            break;
                        case 4:
                            Console.Clear();
                            per.PeopleList();
                            Console.ReadKey();
                            break;
                        case 5:
                            Environment.Exit(0);
                            break;
                    }
                }
                catch 
                {
                    Console.Clear();
                    Console.WriteLine("Můžete zadat pouze číslo ve správném rozmezí");
                    Console.ReadKey();
                }

            }
        }
    }
}