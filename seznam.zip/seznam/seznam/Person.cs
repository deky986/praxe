﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace seznam
{
    public class Person
    {
        public string name { get; set; }
        public string surname { get; set; }

        public List<Person> people = new List<Person>();
        public override string ToString()
        {
            return $"{name} {surname}";
        }
        public void PeopleList() 
        {
            int i = 1;
            foreach (Person person in this.people)
            {
                Console.WriteLine(Convert.ToString(i) + ". " + person);
                i++;
            }
        }
    }
}

