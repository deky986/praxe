﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Karta
{
    public partial class PointEdit : UserControl
    {
        private Pozice bod;
        public Pozice Bod { 
            get
            {
                bod.x = Convert.ToDouble(textBox1.Text);
                bod.y = Convert.ToDouble(textBox2.Text);
                return bod;
            }
            set
            {
                bod = value;
                textBox1.Text = bod.x.ToString();
                textBox2.Text = bod.y.ToString();
            }
        }

        public PointEdit()
        {
            InitializeComponent();
        }
    }
}
