using PdfSharp.Drawing;
using System.Drawing;

namespace Karta
{
    public partial class Form1 : Form
    {
        Contoller contoller = new Contoller();
        List<Rectangle> rectangles = new List<Rectangle>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            XUnit xWidth = XUnit.FromMillimeter(85.6);
            XUnit xHeight = XUnit.FromMillimeter(53.98);
            int pointWidth = Convert.ToInt32(Math.Round(xWidth.Point * 4.16666));
            int pointHeight = Convert.ToInt32(Math.Round(xHeight.Point * 4.16666));
            Width = pointWidth; //500;
            Height = pointHeight; //350;

            contoller.LoadCardsFromFiles();

            pictureBox1.Paint += pictureBox1_Paint;
            //this.pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            contoller.LoadCardsFromFiles();
            MessageBox.Show("data byla na�tena");
        }

        private void button_generatePDF_Click(object sender, EventArgs e)
        {
            contoller.MakePDF();
        }
        private void button_edit_Click_1(object sender, EventArgs e)
        {
            pictureBox1.Enabled = true;
            pictureBox1.Visible = true;
            button_delete.Visible = true;
            button_delete.Enabled = true;
            button_refresh.Enabled = true;
            button_refresh.Visible = true;
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new Pen(Color.Black);
            foreach (Rectangle rectangle in rectangles)
            {
                e.Graphics.DrawRectangle(pen, rectangle);
            }
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            int x = (int)e.X;
            int y = (int)e.Y;
            int w = pictureBox1.Width;
            int h = pictureBox1.Height;

            if (w - 40 >= x && h - 10 >= y)
            {
                contoller.PridatPoziciTextu(x, y);
                Rectangle rectangle = new Rectangle(x, y, 40, 10);
                rectangles.Add(rectangle);
                pictureBox1.Invalidate();
                RefreshPositions();
            }
        }

        private void pictureBox1_Load(object sender, EventArgs e)
        {
            XUnit xWidth = XUnit.FromMillimeter(85.6);
            XUnit xHeight = XUnit.FromMillimeter(53.98);
            int pointWidth = Convert.ToInt32(Math.Round(xWidth.Point * 4.16666));
            int pointHeight = Convert.ToInt32(Math.Round(xHeight.Point * 4.16666));
            Width = pointWidth;
            Height = pointHeight;
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            contoller.poziceTxt.Clear();
            rectangles.Clear();
            RefreshPositions();
            pictureBox1.Invalidate();
        }

        public void RefreshPositions()
        {
            panel1.Controls.Clear();
            int top = 0;
            int pointEditHeight = 50;
            foreach (var pos in contoller.poziceTxt)
            {
                panel1.Controls.Add(new PointEdit() { Left = 5, Top = top, Bod = pos });
                top += pointEditHeight;
            }

        }
        private void button_refresh_Click(object sender, EventArgs e)
        {
            pictureBox1.Invalidate();
        }
    }
}