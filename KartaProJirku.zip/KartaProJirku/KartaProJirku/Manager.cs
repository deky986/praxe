﻿using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PdfSharp.Drawing;
using PdfSharp.Pdf;

namespace KartaProJirku
{
    internal class Manager
    {
        public class Manager : Card
        {
            public void GeneratePDF()
            {
                PdfDocument pdf = new PdfDocument();
                PdfPage page = pdf.AddPage();
                page.Width = XUnit.FromMillimeter(210);
                page.Height = XUnit.FromMillimeter(297);
                XGraphics gfx = XGraphics.FromPdfPage(page);

                int cardsPerRow = 2;
                int cardWidth = 240;
                int cardHeight = 160;
                int margin = 20;
                int spacing = 10;

                int x = margin;
                int y = margin;

                for (int i = 0; i < images.Count && i * 3 + 2 < texts.Count; i++)
                {
                    gfx.DrawRectangle(XPens.Black, x, y, cardWidth, cardHeight);

                    using (MemoryStream ms = new MemoryStream())
                    {
                        images[i].Save(ms, ImageFormat.Png);
                        XImage img = XImage.FromStream(ms);
                        gfx.DrawImage(img, x + 10, y + 10, 80, 100);
                    }

                    var font = new XFont("Arial", 10);
                    gfx.DrawString(texts[i * 3], font, XBrushes.Black, new XPoint(x + 100, y + 30));
                    gfx.DrawString(texts[i * 3 + 1], font, XBrushes.Black, new XPoint(x + 100, y + 50));
                    gfx.DrawString(texts[i * 3 + 2], font, XBrushes.Black, new XPoint(x + 100, y + 70));

                    if ((i + 1) % cardsPerRow == 0)
                    {
                        x = margin;
                        y += cardHeight + spacing;
                    }
                    else
                    {
                        x += cardWidth + spacing;
                    }

                    if (y + cardHeight > page.Height.Point)
                    {
                        page = pdf.AddPage();
                        page.Width = XUnit.FromMillimeter(210);
                        page.Height = XUnit.FromMillimeter(297);
                        gfx = XGraphics.FromPdfPage(page);
                        x = margin;
                        y = margin;
                    }
                }

                pdf.Save(@"C:\Users\Klepacev\Desktop\pdf");
            }

            public void AddText()
            {
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

                string textPath = @"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\txt\";
                int getCount = Directory.GetFiles(textPath).Length;

                for (int i = 0; i < getCount; i++)
                {
                    string next = $@"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\txt\ID_Person_{i}.txt";
                    string[] done = File.ReadAllLines(next, Encoding.GetEncoding(1250));
                    texts.AddRange(done);
                }
            }

            public void AddPictures()
            {
                string picturePath = @"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\obr";
                int getCount = Directory.GetFiles(picturePath).Length;

                for (int i = 0; i < getCount; i++)
                {
                    images.Add(new Bitmap($@"C:\Users\Klepacev\Desktop\Karta\Karta\10_Lidí\obr\ID_Person_{i}.jpg"));
                }
            }

            public override string ToString()
            {
                return string.Join(Environment.NewLine, texts);
            }
        }
    }
}
