﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KartaProJirku
{
    internal class Card
    {
            public System.Drawing.Image image { get; set; }

            public List<string> texts = new List<string>();
            public List<Bitmap> images = new List<Bitmap>();
    }
}
